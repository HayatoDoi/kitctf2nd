import hashlib
def base_str(n, radix):
    digits = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*_+-="

    def num_check(attr, i):
        try:
            return int(i)
        except:
            raise ValueError('invalid %s : %s' % (attr, i))

    n = num_check('n', n)
    radix = num_check('radix', radix)

    if not 1 < radix < 76:
        raise ValueError('invalid radix %s' % radix)

    is_negative = n < 0
    n = abs(n)
    result = []

    while n:
        result.insert(0, n % radix)
        n /= radix
        if n == 0:
            break

    s = ''. join([digits[i] for i in result])
    if is_negative:
        s = '-' + s
    return s

i = 0
data = ""
if __name__ == "__main__":
    while len(base_str(i,75)) < 5:
        data = "kitctf{" + base_str(i, 75) + "}"
        print "%s"%data
        if hashlib.md5(data).hexdigest() == "1503645e4c6bc6468b356cfd8b43e8c0":
            print "flag = %s" %data
            exit(0)
        i+=1
