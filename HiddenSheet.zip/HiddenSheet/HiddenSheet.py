#-*- coding: utf-8 -*-
import sys
fname = 'HiddenSheet.xlsx'
outfname = 'HiddenSheet.out.xlsx'
count = 0
data = ''
try:
    f = open(fname,'rb')
except:
    print 'Usage %s is not found.' % fname
    quit()
for char in f.read():
    print '%02x' % ord(char),
    data +=ord(char)
    count += 1
    if count % 16 == 0:
        print
f.close()
fo = open(outfname,"w")
fo.write(data)
fo.close